package com.api.infood.models;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "TB_CAMPUS")
public class CampusModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
	@Column(nullable = false, length = 120)
    private String enderecoCampus;
    @Column(nullable = false, length = 100)
    private String nomeCampus;
    
	public UUID getId() {
		return id;
	}
	public void setId(UUID id) {
		this.id = id;
	}
	public String getEnderecoCampus() {
		return enderecoCampus;
	}
	public void setEnderecoCampus(String enderecoCampus) {
		this.enderecoCampus = enderecoCampus;
	}
	public String getNomeCampus() {
		return nomeCampus;
	}
	public void setNomeCampus(String nomeCampus) {
		this.nomeCampus = nomeCampus;
	}
	
  
}
