package com.api.infood.repositories;

import com.api.infood.models.ProdutoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface InfoodRepository extends JpaRepository<ProdutoModel, UUID> {

    boolean existsByNomeVendedor(String nomeVendedor);
}
