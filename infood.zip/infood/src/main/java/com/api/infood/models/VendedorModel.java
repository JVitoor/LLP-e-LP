package com.api.infood.models;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "TB_VENDEDOR")
public class VendedorModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
	@Column(nullable = false, length = 100)
    private String nomeVendedor;
    @Column(nullable = false, length = 30)
    private String campusVendedor;
	
    public UUID getId() {
		return id;
	}
	public void setId(UUID id) {
		this.id = id;
	}
	public String getNomeVendedor() {
		return nomeVendedor;
	}
	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}
	public String getCampusVendedor() {
		return campusVendedor;
	}
	public void setCampusVendedor(String campusVendedor) {
		this.campusVendedor = campusVendedor;
	}
}
