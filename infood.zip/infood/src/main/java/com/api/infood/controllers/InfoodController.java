package com.api.infood.controllers;

import com.api.infood.dtos.InfoodDto;
import com.api.infood.models.ProdutoModel;
import com.api.infood.services.InfoodService;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import javax.xml.ws.Response;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping("/infood")
public class InfoodController {

    final InfoodService infoodService;

    public InfoodController(InfoodService infoodService){
        this.infoodService = infoodService;
    }

    @PostMapping
    public ResponseEntity<Object> saveInfood(@RequestBody @Valid InfoodDto infoodDto){
        if(infoodService.existsByNomeVendedor(infoodDto.getNomeVendedor())){
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Conflict: Nome do vendedor já está sendo usado!");
        }

        var infoodModel = new ProdutoModel();
        BeanUtils.copyProperties(infoodDto, infoodModel);
        return ResponseEntity.status(HttpStatus.CREATED).body(infoodService.save(infoodModel));
    }

    @GetMapping
    public ResponseEntity<List<ProdutoModel>> getAllInfood(@PageableDefault(page = 0, size = 10, sort = "id", direction = Sort.Direction.ASC) Pageable pageable){
        return ResponseEntity.status(HttpStatus.OK).body(infoodService.findAll(pageable));
    }

    @GetMapping
    public ResponseEntity<List<Object>> getOneInfood(@PathVariable(value = "id") UUID id){
        Optional<ProdutoModel> infoodModelOptional = infoodService.findById(id);
        if (!infoodModelOptional.isPresent()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado!");
        }
        return ResponseEntity.status(HttpStatus.OK).body(infoodModelOptional.get());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteInfood(@PathVariable(value = "id") UUID id){
        Optional<ProdutoModel> infoodModelOptional = infoodService.findById(id);
        if(!infoodModelOptional.isPresent()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado.");
        }
        infoodService.delete(infoodModelOptional.get());
        return ResponseEntity.status(HttpStatus.OK).body("Produto deletado com sucesso.");
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateInfood(@PathVariable(value = "id") UUID id,
                                               @RequestBody @Valid InfoodDto infoodDto){
        Optional<ProdutoModel> infoodModelOptional = infoodService.findById();
        if (!infoodModelOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado.");
        }
        var infoodModel = infoodModelOptional.get();
        infoodModel.setNomeProduto(infoodDto.getNomeProduto());
        infoodModel.setTipoProduto(infoodDto.getTipoProduto());
        infoodModel.setValorProduto(infoodDto.getValorProduto());
        infoodModel.setNomeVendedor(infoodDto.getNomeVendedor());
        infoodModel.setCampusVendedor(infoodDto.getCampusVendedor());

        return ResponseEntity.status(HttpStatus.OK).body(infoodService.save(infoodModel));
    }
}
