package com.api.infood.services;

import com.api.infood.models.ProdutoModel;
import com.api.infood.repositories.InfoodRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class InfoodService {

    final InfoodRepository infoodRepository;

    public InfoodService(InfoodRepository infoodRepository) {
        this.infoodRepository = infoodRepository;
    }

    @Transactional
    public ProdutoModel save(ProdutoModel infoodModel) {
        return infoodRepository.save(infoodModel);
    }

    public boolean existsByNomeVendedor(String nomeVendedor) {
        return infoodRepository.existsByNomeVendedor(nomeVendedor);
    }

    public List<ProdutoModel> findAll() {
        return infoodRepository.findAll();
    }

    public Optional<ProdutoModel> findById(UUID id){
        return infoodRepository.findById(id);
    }

    @Transactional
    public void delete(ProdutoModel infoodModel){
        infoodRepository.delete(infoodModel);
    }
}
