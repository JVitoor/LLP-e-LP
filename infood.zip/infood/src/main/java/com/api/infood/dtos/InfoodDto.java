package com.api.infood.dtos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class InfoodDto {

    @NotBlank
    private String nomeProduto;
    @NotBlank
    @Size(max = 20)
    private String tipoProduto;
    @NotBlank
    private String valorProduto;
    @NotBlank
    private String nomeVendedor;
    @NotBlank
    private String campusVendedor;

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getTipoProduto() {
        return tipoProduto;
    }

    public void setTipoProduto(String tipoProduto) {
        this.tipoProduto = tipoProduto;
    }

    public String getValorProduto() {
        return valorProduto;
    }

    public void setValorProduto(String valorProduto) {
        this.valorProduto = valorProduto;
    }

    public String getNomeVendedor() {
        return nomeVendedor;
    }

    public void setNomeVendedor(String nomeVendedor) {
        this.nomeVendedor = nomeVendedor;
    }

    public String getCampusVendedor() {
        return campusVendedor;
    }

    public void setCampusVendedor(String campusVendedor) {
        this.campusVendedor = campusVendedor;
    }
}
