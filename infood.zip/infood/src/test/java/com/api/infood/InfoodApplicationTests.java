package com.api.infood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
